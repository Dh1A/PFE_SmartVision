
EN   Your CAD data on 02.03.2018 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 551375 SMT-10M-PS-24V-E-03-L-M8D 
    
    STEP, 551375 SMT-10M-PS-24V-E-0,3-L-M8D, 551375_SMT-10M-PS-24V-E-03-L-M8D.stp
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo AG & Co. KG
    CAD Service
    design_tool@festo.com
    

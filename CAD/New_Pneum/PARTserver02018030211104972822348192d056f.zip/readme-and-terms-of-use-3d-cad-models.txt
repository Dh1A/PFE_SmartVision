
EN   Your CAD data on 02.03.2018 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 543861 SME-8M-DS-24V-K-03-M8D 
    
    STEP, 543861 SME-8M-DS-24V-K-0.3-M8D, 543861_SME-8M-DS-24V-K-03-M8D.stp
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo AG & Co. KG
    CAD Service
    design_tool@festo.com
    


EN   Your CAD data on 14.02.2018 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 18200 10P-10-4A-MP-R-U-4J+ZUYA 
    
    STEP, 18200 10P-10-4A-MP-R-U-4J+ZUYA, 18200_10P-10-4A-MP-R-U-4J_ZUYA.stp
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo AG & Co. KG
    CAD Service
    design_tool@festo.com
    

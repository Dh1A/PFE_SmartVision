
EN   Your CAD data on 08.02.2018 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 163302 DNC-32-650-P-A 
    
    STEP, 163302 DNC-32-650-P-A---(asm_0), 163302_DNC-32-650-P-A.stp
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo AG & Co. KG
    CAD Service
    design_tool@festo.com
    

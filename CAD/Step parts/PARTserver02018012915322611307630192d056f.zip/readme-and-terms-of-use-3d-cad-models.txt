
EN   Your CAD data on 29.01.2018 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 5127 HBN-20/25X1 
    
    STEP, 5127 HBN-20/25x1---(0), 5127_HBN-20_25X1.stp
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo AG & Co. KG
    CAD Service
    design_tool@festo.com
    

Nom                           Fiche technique, fichier csv, description du site internet MISUMI

Enquête                       Possibilité d'importer des informations produit MISUMI dans une base de données

Description                   Misumi offre l'information produit en tant que fichier CSV. Le client peut l'importer dans une base de données.

Exemple

Date Creation                 Format de la date de création_yyyymmdd_hhmmss                                                                      p.e. 20160720_22440
Numero Piece                  Numéro de pièce                                                                                                    p.e. SFJ3-10
Numero_Categorie              numéro de catégorie MISUMI catalogue internet                                                                      p.e. M0101000000
Categorie                     Nom de la categorie du produit                                                                                     p.e. Arbres linéaires
Designation                   Nom produit                                                                                                        p.e. Arbres linéaires - Droit
Prix_Monnaie                                                                                                                                     p.e. EUR
Prix_Standard1                Prix unitaire de la 1ère tranche de quantité de commande minimum                                                         p.e. 2.14
Prix_Quantite1                1ère tranche de quantité de commande minimum                                                                             p.e. 2
Prix_Livraison1               Date d'expédition pour la 1ère tranche de quantité de commande minimum                                                      p.e. 7
Prix_Standard2                2. Niveau de prix dans le tableau remise sur volume                                                                p.e. 2.03
Prix_Quantite2                2. Volume dans le tableau de remise sur volume (de C à D)                                                          p.e. 5_12
Prix_Standard3                3. Niveau de prix dans le tableau remise sur volume                                                                p.e. 1.57
Prix_Quantite3                3. Volume dans le tableau de remise sur volume (de E à F)                                                          p.e. 13_19
Prix_Standard4                4. Niveau de prix dans le tableau remise sur volume                                                                p.e. 1.28
Prix_Quantite4                4. Volume dans le tableau de remise sur volume (de G à H)                                                          p.e. 20_49
Prix_Standard5                5. Niveau de prix dans le tableau remise sur volume                                                                p.e. 0.92
Prix_Quantite5                5. Volume dans le tableau de remise sur volume (de I à J)                                                          p.e. 50_300
Prix_Standard6                6. Niveau de prix dans le tableau remise sur volume                                                                p.e. 0.92
Prix_Quantite6                6. Volume dans le tableau de remise sur volume (de K à L)                                                          p.e. 301_
                                                                                                                                                       *sur 301 pièce
Prix_Standard7                7. Niveau de prix dans le tableau remise sur volume
Prix_Quantite7                7. Volume dans le tableau de remise sur volume (de M à N)
Prix_Standard8                8. Niveau de prix dans le tableau remise sur volume
Prix_Quantite8                8. Volume dans le tableau de remise sur volume (de O à P)
Prix_Standard9                9. Niveau de prix dans le tableau remise sur volume
Prix_Quantite9                9. Volume dans le tableau de remise sur volume (de Q à R)
Prix_Standard10               10. Niveau de prix dans le tableau remise sur volume
Prix_Quantite10               10. Volume dans le tableau de remise sur volume (de S à T)
Prix_Validite                 Format de lavalidité du prix_yyyymmdd_hhmmss                                                                       p.e. 20160720_224400
Designationrealisation N      Description de réalisation et la suivante                                                                          p.e. Forme de base
Realisation N                 L´exécution et la suivante                                                                                        p.e. Droit

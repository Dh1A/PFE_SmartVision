
EN   Your CAD data on 30.01.2018 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 35193 DSNU-25-400-PPV-A 
    
    STEP, 35193 DSNU-25-400-PPV-A---(0), 35193_DSNU-25-400-PPV-A.stp
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo AG & Co. KG
    CAD Service
    design_tool@festo.com
    

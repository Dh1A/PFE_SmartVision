
EN   Your CAD data on 08.02.2018 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 530907 DGC-12-650-G-P-A 
    
    STEP, 530907 DGC-12-650-G-P-A---(0), 530907_DGC-12-650-G-P-A.stp
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo AG & Co. KG
    CAD Service
    design_tool@festo.com
    
